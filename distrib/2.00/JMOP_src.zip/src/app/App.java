/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app;

import i18n.I18N;
import java.awt.Font;
import java.io.File;
import java.util.Enumeration;
import java.util.Locale;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.plaf.FontUIResource;
import resources.icons.IconUtil;
import tools.LAF;
import tools.LOG;
import tools.file.EnvUtil;
import tools.file.FileUtil;
import tools.xml.XML;
import tools.xml.Xml;

/**
 *
 * @author favdb
 */
public class App {

	private static final String TT = "App.";

	public static Pref preferences;
	private static Font fontDef;
	private static MainFrame mainFrame;
	private static boolean dev;

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		initialize(args, "App");
		SwingUtilities.invokeLater(() -> {
			mainFrame = new MainFrame();
			sorterDo();
			mainFrame.setVisible(true);
		});
	}

	public static boolean isDev() {
		return dev;
	}

	public static void initialize(String[] args, String app) {
		String vargs = String.join(" ", args);
		if (args.length == 0) {
			LOG.log(Const.getFullName() + " starting with no option");
		} else {
			LOG.log(Const.getFullName() + " starting with: " + vargs);
			if (args.length > 0) {
				for (String arg : args) {
					switch (arg.toLowerCase()) {
						case "--trace":
							LOG.setTrace();
							break;
						case "--dev":
							dev = true;
							break;
						default:
							break;
					}
				}
			}
		}
		prefInit();
		fontInit();
		LAF.set();
		I18N.initMessages(Locale.getDefault());
		IconUtil.setDefSize();
	}

	public static void fontInit() {
		/*Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int sz = ((int) d.getHeight() / 720) * 20;*/
		int sz = preferences.getInteger(Pref.KEY.FONT_SIZE);
		fontDef = new Font("dialog", Font.PLAIN, sz);
		UIDefaults defaults = UIManager.getDefaults();
		Enumeration newKeys = defaults.keys();
		while (newKeys.hasMoreElements()) {
			Object obj = newKeys.nextElement();
			Object current = UIManager.get(obj);
			if (current instanceof FontUIResource) {
				UIManager.put(obj, new FontUIResource(fontGet()));
			} else if (current instanceof Font) {
				UIManager.put(obj, fontGet());
			}
		}
	}

	public static Font fontGet() {
		return fontDef;
	}

	public static void fontSet(Font font) {
		preferences.setInteger(Pref.KEY.FONT_SIZE, font.getSize());
		int sz = preferences.getInteger(Pref.KEY.FONT_SIZE);
		fontDef = new Font("dialog", Font.PLAIN, sz);
		if (mainFrame != null) {
			SwingUtilities.updateComponentTreeUI(mainFrame);
		}
	}

	private static void prefInit() {
		//LOG.trace(TT + "initPref()");
		preferences = new Pref();
	}

	public static void exit() {
		mainFrame.getAlbumPanel().getTable().save();
		preferences.save();
		System.exit(0);
	}

	public static void close() {
	}

	public static boolean jpegIs(File f) {
		if (!f.isFile()) {
			return false;
		}
		String str = f.getName().toLowerCase();
		return (str.endsWith(".jpg") || str.endsWith(".jpeg"));
	}

	public static int jpegCount(File dir) {
		//LOG.trace(TT + "countJPEG(dir=" + dir.getAbsolutePath() + ")");
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return 0;
		}
		int nb = 0;
		for (File f : files) {
			if (f.isDirectory()) {
				nb += jpegCount(f);
			} else {
				if (App.jpegIs(f)) {
					nb++;
				}
			}
		}
		return nb;
	}

	public static void photosDirSelect() {
		String dir = App.preferences.photosDirGet();
		if (dir.isEmpty()) {
			dir = EnvUtil.getPhotosDir().getAbsolutePath();
		}
		JFileChooser chooser = new JFileChooser(dir);
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		if (chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) {
			return;
		}
		String newdir = chooser.getSelectedFile().getAbsolutePath();
		preferences.photosDirSet(newdir);
		mainFrame.setPhotosDir(new File(newdir));
		Xml xml = mainFrame.getAlbumPanel().getXml();
		File file = new File(newdir + File.separator + "Album.xml");
		mainFrame.setAlbumFile(file);
	}

	private static void albumFileSet(File file) {
		preferences.albumLastSet(file.getName());
		mainFrame.setAlbumFile(file);
	}

	static void albumFileNew() {
		FileNameExtensionFilter xmlfilter = new FileNameExtensionFilter("xml files (*.xml)", "xml");
		String base = preferences.photosDirGet() + File.separator + "Album";
		File inf = new File(base + ".xml");
		int i = 1;
		while (inf.exists()) {
			inf = new File(String.format("%s%02d.xml", base, i++));
			if (i > 20) {
				break;
			}
		}
		if (i > 20) {
			JOptionPane.showMessageDialog(mainFrame,
					I18N.getMsg("album.error_toomuch", inf),
					"album",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		JFileChooser chooser = new JFileChooser(inf);
		chooser.setSelectedFile(inf);
		chooser.setFileFilter(xmlfilter);
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		if (chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) {
			return;
		}
		String str = chooser.getSelectedFile().getAbsolutePath();
		if (!str.endsWith(".xml")) {
			str += ".xml";
		}
		File file = new File(str);
		if (!file.exists()) {
			//create an empty Album file
			FileUtil.fileWriteString(file,
					XML.getHeader()
					+ "<album>"
					+ "<pref mode=\"0\" tempo=\"0\" comment=\"{JJ/MM/AA}\" />"
					+ "<list/>"
					+ "</album>"
			);
			mainFrame.setAlbumFile(file);
		} else {
			JOptionPane.showMessageDialog(mainFrame,
					I18N.getMsg("album.error_exists", file),
					I18N.getMsg("app.album"),
					JOptionPane.ERROR_MESSAGE);
		}
	}

	public static void albumFileOpen() {
		FileNameExtensionFilter xmlfilter = new FileNameExtensionFilter("xml files (*.xml)", "xml");
		JFileChooser chooser = new JFileChooser(preferences.photosDirGet());
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		chooser.setFileFilter(xmlfilter);
		int i = chooser.showOpenDialog(null);
		if (i != JFileChooser.APPROVE_OPTION) {
			return;
		}
		mainFrame.setAlbumFile(chooser.getSelectedFile());
	}

	public static void aboutDo() {
		AboutDlg dlg = new AboutDlg(mainFrame);
		dlg.setVisible(true);
	}

	public static void sorterDo() {
		mainFrame.doSorter();
	}

	public static void albumDo() {
		mainFrame.doAlbum();
	}

	public static void albumRefresh() {
		mainFrame.refreshAlbum();
	}

	public static void updateTitle() {
		if (mainFrame != null) {
			mainFrame.updateTitle();
			diaporamaEnable();
		}
	}

	public static void diapoDo() {
		mainFrame.doDiaporama();
	}

	public static void diaporamaEnable() {
		if (mainFrame != null) {
			boolean b = mainFrame.getAlbumPanel().getTable().getRowCount() > 0;
			if (mainFrame.appMenu.btDiapo != null) {
				mainFrame.appMenu.btDiapo.setVisible(b);
				mainFrame.appMenu.btExport.setVisible(b);
			}
		}
	}

	public static void exportDo() {
		//LOG.trace(TT+"exportDo()");
		mainFrame.exportDo();
	}

	public static void zoom() {
		ZoomDlg dlg = new ZoomDlg(mainFrame);
		dlg.setVisible(true);
	}

	public static void setLaf() {
		LOG.trace(TT + "setLaf()");
		//if (mainFrame == null) {
		//	return;
		//}
		try {
			/*UIManager.setLookAndFeel(new NimbusLookAndFeel());
			if (preferences.getDarkLaf()) {
				UIManager.put("control", new Color(128, 128, 128));
				UIManager.put("info", new Color(128, 128, 128));
				UIManager.put("nimbusBase", new Color(18, 30, 49));
				UIManager.put("nimbusAlertYellow", new Color(248, 187, 0));
				UIManager.put("nimbusDisabledText", new Color(128, 128, 128));
				UIManager.put("nimbusFocus", new Color(115, 164, 209));
				UIManager.put("nimbusGreen", new Color(176, 179, 50));
				UIManager.put("nimbusInfoBlue", new Color(66, 139, 221));
				UIManager.put("nimbusLightBackground", new Color(18, 30, 49));
				UIManager.put("nimbusOrange", new Color(191, 98, 4));
				UIManager.put("nimbusRed", new Color(169, 46, 34));
				UIManager.put("nimbusSelectedText", new Color(255, 255, 255));
				UIManager.put("nimbusSelectionBackground", new Color(104, 93, 156));
				UIManager.put("text", new Color(230, 230, 230));
			}*/
			if (mainFrame != null) {
				SwingUtilities.updateComponentTreeUI(mainFrame);
			}
		} catch (Exception exc) {
			LOG.err("Nimbus: Unsupported Look and feel!");
		}
	}

}
