JPMS

Please check http://psa66430.free.fr/JPMS for more
---
Please install or update Java (minimal version 8).
---
Which file to use?

Linux:
- Debian users : jpms.deb
- RPM based users : jpms.rpm
- All others Linux users : jpms.zip
(unzip this file into your jpms folder)

Mac OS X : jpms-macOSx.tar.gz
(extract this content into your oStrybook folder)

Windows users : jpms.exe

where X is the version major, and ZZ is the version minor

Project source code : jpms-src.zip

---
Please install or update Java (minimal version 8).
---
