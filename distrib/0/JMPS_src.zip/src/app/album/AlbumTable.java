/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app.album;

import app.App;
import java.io.File;
import java.io.FileNotFoundException;
import javax.swing.JTable;
import tools.LOG;
import tools.xml.Xml;

/**
 *
 * @author favdb
 */
public class AlbumTable {

	private static final String TT = "AlbumTable.";
	private final JTable table;
	private Xml xml;
	private AlbumPref albumPref = new AlbumPref();

	public AlbumTable(JTable table) {
		this.table = table;
		initialize();
	}

	private void initialize() {
		try {
			xml = new Xml(App.preferences.photosDirGet() + File.separator + "Album.xml");
			xml.open();
			loadAlbum();
		} catch (FileNotFoundException ex) {
			LOG.err(TT + "initialize()", ex);
		}
	}

	public void setFile(File file) {
		try {
			xml = new Xml(file);
			xml.open();
			loadAlbum();
		} catch (FileNotFoundException ex) {
			LOG.err(TT + "initialize()", ex);
		}
	}

	public static void initColumns(JTable table) {
		table.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
		TableColumnAdjuster tca = new TableColumnAdjuster(table);
		tca.adjustColumns();
	}

	public void loadAlbum() {

	}

}
