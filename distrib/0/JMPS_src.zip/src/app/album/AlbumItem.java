/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app.album;

import java.io.File;

/**
 *
 * @author favdb
 */
public class AlbumItem {

	private File file;
	private String text;

	public AlbumItem(File file) {
		this.file = file;
	}

	public AlbumItem(File file, String text) {
		this(file);
		this.text = text;
	}

	public void setFile(File value) {
		this.file = value;
	}

	public File getFile() {
		return file;
	}

	public void setText(String value) {
		this.text = value;
	}

	public String getText() {
		return text;
	}

}
