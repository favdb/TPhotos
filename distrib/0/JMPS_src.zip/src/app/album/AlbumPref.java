/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app.album;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import tools.xml.Xml;
import tools.xml.XmlUtil;

/**
 *
 * @author favdb
 */
public class AlbumPref {

	private String name = "Album";
	Integer mode = 0, tempo = 0;

	public AlbumPref() {

	}

	public AlbumPref(Xml xml) {
		Node n = xml.getNode("pref");
		name = XmlUtil.getString(n, "name");
		mode = XmlUtil.getInteger(n, "mode");
		tempo = XmlUtil.getInteger(n, "tempo");
	}

	public void setName(String value) {
		this.name = value;
	}

	public String getName() {
		return name;
	}

	public void setMode(int value) {
		this.mode = value;
	}

	public Integer getMode() {
		return mode;
	}

	public void setTempo(int value) {
		this.tempo = value;
	}

	public Integer getTempo() {
		return tempo;
	}

	public void updateXml(Xml xml) {
		Element n = (Element) xml.getNode("pref");
		if (n == null) {
			n = xml.getDocument().createElement("pref");
			xml.getRoot().appendChild(n);
		}
		n.setAttribute("name", name);
		n.setAttribute("mode", mode.toString());
		n.setAttribute("tempo", tempo.toString());
	}

}
