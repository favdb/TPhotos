/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app.album;

import app.App;
import java.io.File;
import java.util.Arrays;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import resources.icons.ICONS;
import resources.icons.IconUtil;
import tools.LOG;

/**
 *
 * @author favdb
 */
public class AlbumTree {

	private static final String TT = "AlbumTree.";

	public static TreeModel initModel(JTree tree, File rootDir, DefaultMutableTreeNode rootNode) {
		DefaultTreeModel treeModel = new DefaultTreeModel(getRootNode());
		DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) tree.getCellRenderer();
		renderer.setClosedIcon(IconUtil.getIconSmall(ICONS.K.FOLDER));
		renderer.setOpenIcon(IconUtil.getIconSmall(ICONS.K.FOLDER_OPEN));
		renderer.setLeafIcon(IconUtil.getIconSmall(ICONS.K.PIC));
		createChildren(rootDir, rootNode);
		tree.expandRow(0);
		return treeModel;
	}

	public static DefaultMutableTreeNode getRootNode() {
		File rootDir = new File(App.preferences.photosDirGet());
		return new DefaultMutableTreeNode(new FileNode(rootDir));
	}

	public static void loadTree(JTree tree, File rootDir, DefaultMutableTreeNode rootNode) {
		LOG.trace(TT + "loadTree()");
		createChildren(rootDir, rootNode);
		tree.expandRow(0);
	}

	static String getPath(DefaultMutableTreeNode node) {
		TreeNode[] str = node.getPath();
		StringBuilder rc = new StringBuilder();
		for (TreeNode n : str) {
			if (n.toString().equals(getRootNode().toString())) {
				continue;
			}
			if (rc.length() > 1) {
				rc.append(File.separator);
			}
			rc.append(n.toString());
		}
		return App.preferences.photosDirGet() + File.separator + rc.toString();
	}

	static String getNodePath(DefaultMutableTreeNode node) {
		TreeNode[] str = node.getPath();
		StringBuilder rc = new StringBuilder();
		for (TreeNode n : str) {
			if (n.toString().equals(getRootNode().toString())) {
				continue;
			}
			if (rc.length() > 1) {
				rc.append(File.separator);
			}
			rc.append(n.toString());
		}
		return rc.toString();
	}

	public static class FileNode {

		private final File file;

		public FileNode(File file) {
			this.file = file;
		}

		@Override
		public String toString() {
			String name = file.getName();
			if (name.equals("")) {
				return file.getAbsolutePath();
			} else {
				return name;
			}
		}
	}

	public static void createChildren(File fileRoot, DefaultMutableTreeNode node) {
		//LOG.trace(TT + "createChildren(root=" + fileRoot.getName() + ", node=" + node.getPath() + ")");
		File[] files = fileRoot.listFiles();
		if (files == null) {
			return;
		}
		Arrays.sort(files);
		for (File file : files) {
			DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(new FileNode(file));
			if (App.isJPEG(file) || file.isDirectory()) {
				node.add(childNode);
			}
			if (file.isDirectory()) {
				createChildren(file, childNode);
			}
		}
	}

}
