/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app;

import i18n.I18N;
import java.awt.Dimension;
import java.awt.Font;
import static java.awt.Font.PLAIN;
import java.awt.Toolkit;
import java.io.File;
import java.util.Enumeration;
import java.util.Locale;
import javax.swing.SwingUtilities;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;
import resources.icons.IconUtil;
import tools.LOG;

/**
 *
 * @author favdb
 */
public class App {

	private static final String TT = "App.";

	public static Pref preferences;
	private static Font fontDef;
	private static FrmBlank frmBlank;

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		initialize(args, "App");
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				frmBlank = new FrmBlank();
				frmBlank.setVisible(true);
			}
		});
	}

	public static void initialize(String[] args, String app) {
		String vargs = String.join(" ", args);
		if (args.length == 0) {
			LOG.log(Const.getFullName() + " starting " + I18N.getMsg(app) + " with no option");
		} else {
			LOG.log(Const.getFullName() + " starting " + I18N.getMsg(app) + " with: " + vargs);
			if (args.length > 0) {
				for (String arg : args) {
					switch (arg.toLowerCase()) {
						case "--trace":
							LOG.setTrace();
							break;
						default:
							break;
					}
				}
			}
		}
		fontInit();
		initPref();
		I18N.initMessages(Locale.getDefault());
		IconUtil.setDefSize();
		LOG.init();
		LOG.setTrace();
	}

	public static void fontInit() {
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int sz = (int) d.getWidth() / 800 * 10;
		fontDef = new Font("dialog", PLAIN, sz);
		UIDefaults defaults = UIManager.getDefaults();
		Enumeration newKeys = defaults.keys();
		while (newKeys.hasMoreElements()) {
			Object obj = newKeys.nextElement();
			Object current = UIManager.get(obj);
			if (current instanceof FontUIResource) {
				defaults.put(obj, new FontUIResource(App.fontGetDef()));
			} else if (current instanceof Font) {
				defaults.put(obj, App.fontGetDef());
			}
		}
	}

	public static Font fontGetDef() {
		return fontDef;
	}

	private static void initPref() {
		LOG.trace(TT + "initPref()");
		preferences = new Pref();
		//preferences.initFont();
	}

	/*public App() {
		fontInit();
		I18N.initMessages(Locale.getDefault());
		IconUtil.setDefSize();
		initPref();
		LOG.init();
		LOG.setTrace();
	}*/
	public static void exit() {
		preferences.save();
		System.exit(0);
	}

	public static void close() {
		if (frmBlank != null) {
			frmBlank.setVisible(true);
		}
	}

	public static boolean isJPEG(File f) {
		if (!f.isFile()) {
			return false;
		}
		String str = f.getName().toLowerCase();
		return (str.endsWith(".jpg") || str.endsWith(".jpeg"));
	}

}
