/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app.sorter;

import app.App;
import app.Const;
import i18n.I18N;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import resources.icons.ICONS;
import resources.icons.IconUtil;
import tools.Html;
import tools.file.EnvUtil;
import tools.file.FileUtil;

/**
 *
 * @author favdb
 */
public class SorterFrame extends JFrame {

	private static final String TT = "FrmSorter.";

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		App.initialize(args, "app.app_sorter");
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				JFrame frm = new SorterFrame();
				frm.setVisible(true);
			}
		});
	}

	public JTextField tfFolder;
	private JTextPane taInfos;
	private JButton btSort;
	public JComboBox mode;
	public JCheckBox ckRemove;

	public SorterFrame() {
		super();
		initAll();
	}

	private void initAll() {
		init();
		initUi();
	}

	private void init() {
		//LOG.trace(TT + "init()");
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent event) {
				doExit();
			}
		});
	}

	private void initUi() {
		//LOG.trace(TT + "initUi()");
		setLayout(new BorderLayout());
		updateTitle();
		this.setIconImage(IconUtil.getIconImageSmall(ICONS.K.JPMS));
		add(initTfFolder(), BorderLayout.PAGE_START);
		taInfos = new JTextPane();
		taInfos.setContentType("text/html");
		setInfos(Html.getHome());
		JScrollPane scroll = new JScrollPane(taInfos);
		scroll.setPreferredSize(new Dimension(800, 600));
		add(scroll, BorderLayout.CENTER);
		add(initButtons(), BorderLayout.PAGE_END);
		this.pack();
		this.setLocationRelativeTo(null);
	}

	@SuppressWarnings("unchecked")
	private JPanel initTfFolder() {
		//LOG.trace(TT + "initTfFolder()");
		JPanel pp = new JPanel(new BorderLayout());
		JPanel p0 = new JPanel(new BorderLayout());
		tfFolder = new JTextField();
		tfFolder.setColumns(32);
		JButton btFolder = IconUtil.getIconButton(ICONS.K.F_OPEN, "dir.select");
		btFolder.addActionListener((ActionEvent evt) -> {
			String dir = tfFolder.getText();
			if (dir.isEmpty()) {
				dir = EnvUtil.getHomeDir().getAbsolutePath();
			}
			JFileChooser chooser = new JFileChooser(dir);
			chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			int i = chooser.showOpenDialog(null);
			if (i != 0) {
				return;
			}
			File file = chooser.getSelectedFile();
			String fx = file.getAbsolutePath() + File.separator;
			String outdir = App.preferences.photosDirGet() + File.separator;
			if (file.isFile()) {
				fx = new File(file.getParent()) + File.separator;
			}
			if (fx.startsWith(outdir)) {
				setInfos(getInfos() + Html.getError(I18N.getMsg("dir.err_photos")));
				return;
			}
			tfFolder.setText(file.getAbsolutePath());
			refreshFiles();
		});
		p0.add(FileUtil.initDirSelect("dir.source", tfFolder, btFolder), BorderLayout.WEST);
		JPanel p02 = new JPanel();
		JButton btPref = IconUtil.getIconButton(ICONS.K.COGS, "app.pref");
		btPref.addActionListener(e -> setPref());
		p02.add(btPref);
		p02.add(new JLabel(" "));
		p0.add(p02, BorderLayout.EAST);
		pp.add(p0, BorderLayout.PAGE_START);
		JPanel p2 = new JPanel();
		p2.add(ckRemove = new JCheckBox(I18N.getMsg("photo.remove")));
		JPanel p20 = new JPanel();
		p2.add(p20);
		p20.setBorder(BorderFactory.createEtchedBorder());
		p20.add(new JLabel(I18N.getColonMsg("sort.by")));
		p20.add(mode = new JComboBox(new String[]{
			I18N.getMsg("sort.by_year"),
			I18N.getMsg("sort.by_month"),
			I18N.getMsg("sort.by_day")
		}));
		p2.add(new JLabel("               "));
		btSort = new JButton(I18N.getMsg("app.exec"));
		btSort.setIcon(IconUtil.getIconSmall(ICONS.K.JPMS));
		btSort.setEnabled(false);
		btSort.addActionListener(e -> doSort());
		tfFolder.addKeyListener(new java.awt.event.KeyAdapter() {
			@Override
			public void keyReleased(java.awt.event.KeyEvent evt) {
				refreshFiles();
			}

		});
		p2.add(btSort);
		pp.add(p2, BorderLayout.PAGE_END);
		return pp;
	}

	private JPanel initButtons() {
		//LOG.trace(TT + "initButtons()");
		JPanel p = new JPanel();
		JButton btExit = new JButton(I18N.getMsg("app.exit"));
		btExit.setIcon(IconUtil.getIconSmall(ICONS.K.EXIT));
		btExit.addActionListener(e -> doExit());
		p.add(btExit);
		JPanel pp = new JPanel(new BorderLayout());
		pp.add(p, BorderLayout.EAST);
		return pp;
	}

	public void refreshFiles() {
		//LOG.trace(TT + "refresh()");
		if (tfFolder == null || tfFolder.getText().isEmpty()) {
			return;
		}
		String infos = getInfos();
		File dir = new File(tfFolder.getText());
		int nb = countJPEG(dir);
		String line = I18N.getMsg("dir.contains", new String[]{dir.getAbsolutePath(), nb + ""});
		if (nb == 0) {
			line = Html.getError(I18N.getMsg("dir.contains_nophoto", dir.getAbsolutePath()));
		}
		setInfos(infos + "<p>" + line + "</p>");
		btSort.setEnabled(nb > 0);
	}

	private void doExit() {
		//LOG.trace(TT + "doExit()");
		dispose();
		App.close();
	}

	/**
	 * set infos text
	 */
	public void setInfos(String txt) {
		//LOG.trace(TT+"setInfos(txt="+txt+")");
		taInfos.setText(Html.intoHtml(txt));
		taInfos.setCaretPosition(taInfos.getDocument().getLength());
		taInfos.repaint();
	}

	/**
	 * get only body part of infos
	 *
	 * @return
	 */
	public String getInfos() {
		//LOG.trace(TT+"getInfos()");
		return Html.getBody(taInfos.getText());
	}

	private void doSort() {
		//LOG.trace(TT + "doSort()");
		if (tfFolder == null || tfFolder.getText().isEmpty()) {
			return;
		}
		File dir = new File(tfFolder.getText());
		new Thread(new CopyFile(this, dir)).start();
		btSort.setEnabled(false);
	}

	private void exit() {
		dispose();
		System.exit(0);
	}

	public void setPref() {
		//LOG.trace(TT+"setPref()");
		String dir = App.preferences.photosDirGet();
		if (dir.isEmpty()) {
			dir = EnvUtil.getPhotosDir().getAbsolutePath();
		}
		JFileChooser chooser = new JFileChooser(dir);
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		int i = chooser.showOpenDialog(null);
		if (i != JFileChooser.APPROVE_OPTION) {
			return;
		}
		String file = chooser.getSelectedFile().getAbsolutePath();
		App.preferences.photosDirSet(file);
		updateTitle();
	}

	private void updateTitle() {
		this.setTitle(Const.getName() + " (" + App.preferences.photosDirGet() + ")");
	}

	public boolean autoremove() {
		return ckRemove.isSelected();
	}

	private int countJPEG(File dir) {
		File[] files = dir.listFiles();
		int nb = 0;
		for (File f : files) {
			if (f.isDirectory()) {
				nb += countJPEG(f);
			} else {
				if (!App.isJPEG(f)) {
					continue;
				}
				nb++;
			}
		}
		return nb;
	}

}
