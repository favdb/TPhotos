/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app.sorter;

import app.App;
import i18n.I18N;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import tools.Html;
import tools.LOG;
import tools.exif.ExifData;
import tools.file.FileUtil;

/**
 *
 * @author favdb
 */
public class CopyFile implements Runnable {

	private final SorterFrame parent;
	private final List<File> files;
	private int index;
	private final StringBuilder infos;

	public CopyFile(SorterFrame parent, File dir) {
		this.parent = parent;
		this.files = computeList(dir);
		Collections.sort(files, new Comparator<File>() {
			@Override
			public int compare(File f1, File f2) {
				return f1.getAbsolutePath().compareTo(f2.getAbsolutePath());
			}
		});
		LOG.trace("CopyFile nb of files=" + files.size());
		this.index = 0;
		infos = new StringBuilder(parent.getInfos());
		infos.append(String.format("<p>Rangement des photos:"));
	}

	@Override
	public void run() {
		//LOG.trace(TT + ".run() index=" + index);
		if (index >= files.size()) {
			return;
		}
		File infile = files.get(index);
		int infileMD5 = FileUtil.getMD5(infile);
		String date = ExifData.getDate(infile);
		String nl = "";
		if (date != null) {
			String newname = date;
			String outdir = App.preferences.photosDirGet() + File.separator;
			String subdir = date.substring(0, 4);
			if (parent.mode.getSelectedIndex() > 0) {
				subdir += File.separator + date.substring(4, 6);
			}
			if (parent.mode.getSelectedIndex() == 2) {
				subdir += File.separator + date.substring(6, 8);
			}
			String outname = outdir + subdir + File.separator + newname;
			File outfile = new File(outname + ".jpg");
			String cpl = "";
			int nb = 2;
			if (outfile.exists()) {
				if (infileMD5 == FileUtil.getMD5(outfile)) {
					nb = 100;
				} else {
					for (; nb < 100; nb++) {
						cpl = String.format("_%02d", nb);
						outname = outdir + subdir + File.separator + newname + cpl + ".jpg";
						File fx = new File(outname);
						if (!fx.exists()) {
							break;
						}
						if (infileMD5 == FileUtil.getMD5(fx)) {
							nb = 100;
							break;
						}
					}
				}
				outfile = new File(outdir + subdir + File.separator + newname + cpl + ".jpg");
			}
			if (nb < 100) {
				nl = I18N.getMsg("photo.copy", new String[]{infile.getName(), outfile.getName(), subdir});
				FileUtil.fileCopy(infile, outfile);
				if (parent.autoremove()) {
					infile.delete();
				}
			} else {
				nl = Html.getError(I18N.getMsg("photo.exists", new String[]{infile.getName(), newname + ".jpg"}));
			}
			infos.append("<br>").append(nl);
		}
		if (++index < files.size()) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException ex) {
			}
			run();
		} else {
			infos.append("<br>").append(I18N.getMsg("sort.end", index));
		}
		parent.setInfos(infos.toString() + "</p>");
	}

	private List<File> computeList(File dir) {
		List<File> ls = new ArrayList<>();
		File[] fls = dir.listFiles();
		for (File f : fls) {
			if (f.isDirectory()) {
				ls.addAll(computeList(f));
			} else if (f.isFile()) {
				String str = f.getName().toLowerCase();
				if (!str.endsWith(".jpg") && !str.endsWith(".jpeg")) {
					continue;
				}
				ls.add(f);
			}
		}
		return ls;
	}

}
