/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app;

import app.album.AlbumFrame;
import app.sorter.SorterFrame;
import i18n.I18N;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import resources.icons.ICONS;
import resources.icons.IconUtil;

/**
 *
 * @author favdb
 */
public class FrmBlank extends JFrame {

	private static final String TT = "FrmBlank.";

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		App.initialize(args, "app");
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				JFrame frm = new FrmBlank();
				frm.setVisible(true);
			}
		});
	}
	private JButton btSort;
	private JButton btAlbum;

	// choice beetween Sorter and Album
	public FrmBlank() {
		initialize();
	}

	private void initialize() {
		// no menu, no toolbar
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setTitle(Const.getName());
		JPanel panel = (JPanel) getContentPane();
		setLayout(new BorderLayout());

		btSort = new JButton(I18N.getMsg("app.app_sorter"));
		btSort.setIcon(IconUtil.getIconSmall(ICONS.K.JPMS));
		btSort.addActionListener(e -> doSort());
		panel.add(btSort, BorderLayout.NORTH);

		btAlbum = new JButton(I18N.getMsg("app.app_album"));
		btAlbum.setIcon(IconUtil.getIconSmall(ICONS.K.JPMS));
		btAlbum.addActionListener(e -> doAlbum());
		panel.add(btAlbum, BorderLayout.CENTER);

		JButton btExit = new JButton(I18N.getMsg("app.exit"));
		btExit.setIcon(IconUtil.getIconSmall(ICONS.K.EXIT));
		btExit.addActionListener(e -> doExit());
		panel.add(btExit, BorderLayout.SOUTH);

		pack();
		this.setLocationRelativeTo(null);
		int width = btSort.getSize().width, height = btSort.getSize().height;
		width = Math.max(width, btAlbum.getSize().width);
		height = Math.max(height, btAlbum.getSize().height);
		btSort.setPreferredSize(new Dimension(width, height));
		btAlbum.setPreferredSize(new Dimension(width, height));
		btExit.setPreferredSize(new Dimension(width, height));
		pack();
	}

	private void doSort() {
		SorterFrame sort = new SorterFrame();
		sort.setVisible(true);
		this.setVisible(false);
	}

	private void doAlbum() {
		AlbumFrame album = new AlbumFrame();
		album.setVisible(true);
		this.setVisible(false);
	}

	private void doExit() {
		this.setVisible(false);
		System.exit(0);
	}

}
