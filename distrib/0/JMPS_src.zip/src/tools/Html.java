/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package tools;

import app.App;
import i18n.I18N;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author favdb
 */
public class Html {

	private static final String BR = "<br>";

	public static String getBody(String html) {
		// Expression régulière pour capturer le contenu de la balise <body>
		String bodyPattern = "(?s)<body.*?>(.*?)</body>";
		Pattern pattern = Pattern.compile(bodyPattern, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(html);

		if (matcher.find()) {
			return matcher.group(1);  // Le groupe 1 contient le contenu du body
		} else {
			LOG.err("Html.getBody(html=\n'" + html + "\n' no body part");
			return "";  // Si la balise <body> n'est pas trouvée
		}
	}

	public static String getHome() {
		String str = I18N.getMsg("app.infos");
		return textToHTML(str);

	}

	public static String intoHtml(String html) {
		return "<html>"
			+ "<head>"
			+ "</head>"
			+ "<body style=\""
			+ "font-size: " + App.fontGetDef().getSize() + ";"
			+ "font-family: sans-serif;"
			+ "\">"
			+ html
			+ "</body></html>";
	}

	public static String getError(String msg) {
		return "<font color=\"red\">" + msg + "</font>";
	}

	/**
	 * convert plain text to Html, inserting tags like P or BR
	 *
	 * @param text
	 * @return
	 */
	public static String textToHTML(String text) {
		if (text == null) {
			return "";
		}
		int length = text.length();
		boolean prevSlashR = false;
		StringBuilder out = new StringBuilder();
		for (int i = 0; i < length; i++) {
			char ch = text.charAt(i);
			switch (ch) {
				case '\r':
					if (prevSlashR) {
						out.append(BR);
					}
					prevSlashR = true;
					break;
				case '\n':
					prevSlashR = false;
					out.append(BR);
					break;
				case '"':
					if (prevSlashR) {
						out.append(BR);
						prevSlashR = false;
					}
					out.append("&quot;");
					break;
				case '<':
					if (prevSlashR) {
						out.append(BR);
						prevSlashR = false;
					}
					out.append("&lt;");
					break;
				case '>':
					if (prevSlashR) {
						out.append(BR);
						prevSlashR = false;
					}
					out.append("&gt;");
					break;
				case '&':
					if (prevSlashR) {
						out.append(BR);
						prevSlashR = false;
					}
					out.append("&amp;");
					break;
				default:
					if (prevSlashR) {
						out.append(BR);
						prevSlashR = false;
					}
					out.append(ch);
					break;
			}
		}
		return (out.toString()
			.replace(BR + "-- ", BR + "&emsp;&emsp;◦ ")
			.replace(BR + "- ", BR + "&emsp;• "));
	}

}
