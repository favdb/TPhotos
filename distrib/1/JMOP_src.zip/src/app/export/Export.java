/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app.export;

import api.mig.swing.MigLayout;
import app.AbstractFrame;
import app.MainFrame;
import app.album.AlbumItem;
import app.album.AlbumTable;
import i18n.I18N;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Insets;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import resources.icons.ICONS;
import resources.icons.IconUtil;
import tools.FFmpeg;
import tools.Html;
import tools.LOG;
import tools.MIG;
import tools.Ui;
import tools.file.CopyFileDlg;
import tools.file.EnvUtil;
import tools.file.FileUtil;
import tools.xml.XML;

/**
 *
 * @author favdb
 */
public class Export extends AbstractFrame {

	private static final String TT = "Export.";

	private final AlbumTable table;
	private JTextField tfFolder;
	private JButton btExec;
	private JComboBox cbFormat, cbCompress;
	private File dirDest;
	private final MainFrame mainFrame;
	private Container pane;
	private CopyFileDlg copyDlg;
	private List<AlbumItem> items;
	private static final int FORMAT_SIMPLE = 0, FORMAT_HTML = 1, FORMAT_EPUB = 2, FORMAT_MP4 = 3;
	private static final String FORMAT[] = {
		I18N.getMsg("export.format.simple"),
		I18N.getMsg("export.format.html"),
		I18N.getMsg("export.format.epub"),
		I18N.getMsg("export.format.mpeg")
	};

	@SuppressWarnings("OverridableMethodCallInConstructor")
	public Export(MainFrame mainFrame) {
		super();
		this.mainFrame = mainFrame;
		this.table = mainFrame.getAlbumPanel().getTable();
		initialize();
	}

	@Override
	public void initialize() {
		pane = this.getContentPane();
		pane.setLayout(new MigLayout());
		pane.add(initUpper(), MIG.get(MIG.SPAN, MIG.GROWX));
		taInfos = new JTextPane();
		taInfos.setContentType("text/html");
		initInfos(I18N.getMsg("export.home"));
		JScrollPane scroll = new JScrollPane(taInfos);
		scroll.setPreferredSize(new Dimension(1024, 768));
		pane.add(scroll, MIG.get(MIG.SPAN, MIG.GROW, MIG.CENTER));
	}

	private JPanel initUpper() {
		JPanel p = new JPanel(new MigLayout(MIG.FILL));
		p.add(initFormat(), MIG.get(MIG.SPAN, MIG.SPLIT2));
		p.add(initCompress(), MIG.WRAP);
		p.add(initTfFolder());
		btExec = new JButton(I18N.getMsg("export"));
		btExec.setIcon(IconUtil.getIconSmall(ICONS.K.COGS));
		btExec.setEnabled(!tfFolder.getText().isEmpty());
		btExec.addActionListener(e -> doCopyBegin());
		p.add(btExec, MIG.get(MIG.SPAN, MIG.RIGHT));
		return p;
	}

	private JPanel initTfFolder() {
		//LOG.trace(TT + "initTfFolder()");
		JPanel p2 = new JPanel(new MigLayout());
		p2.add(new JLabel(I18N.getColonMsg("export.dest")), MIG.get(MIG.SPAN, MIG.SPLIT + " 3"));
		tfFolder = new JTextField();
		tfFolder.setColumns(32);
		tfFolder.setEditable(false);
		p2.add(tfFolder);
		JButton bt = Ui.initIconButton("btFolder", ICONS.K.FOLDER, (java.awt.event.ActionEvent evt) -> {
			String dir = tfFolder.getText();
			if (dir.isEmpty()) {
				dir = EnvUtil.getHomeDir().getAbsolutePath();
			}
			JFileChooser chooser = new JFileChooser(dir);
			chooser.setFileSelectionMode(1);
			if (chooser.showOpenDialog(null) != 0) {
				return;
			}
			File file = chooser.getSelectedFile();
			if (file.exists()) {
				tfFolder.setText(file.getAbsolutePath());
			} else {
				tfFolder.setText("");
			}
			btExec.setEnabled(!tfFolder.getText().isEmpty());
		});
		bt.setMargin(new Insets(0, 0, 0, 0));
		p2.add(bt);
		return p2;
	}

	@SuppressWarnings("unchecked")
	private JPanel initFormat() {
		JPanel p = new JPanel(new MigLayout());
		//p.setBorder(BorderFactory.createEtchedBorder());
		p.add(new JLabel(I18N.getColonMsg("export.format")));
		p.add(cbFormat = new JComboBox(FORMAT));
		if (!FFmpeg.isInstalled()) {
			cbFormat.removeItemAt(4);
		}
		return p;
	}

	@SuppressWarnings("unchecked")
	private JPanel initCompress() {
		JPanel p = new JPanel(new MigLayout());
		//p.setBorder(BorderFactory.createEtchedBorder());
		p.add(new JLabel(I18N.getColonMsg("export.compress")));
		p.add(cbCompress = new JComboBox(new String[]{
			I18N.getMsg("export.compress.none"),
			I18N.getMsg("export.compress.mini"),
			I18N.getMsg("export.compress.maxi")
		}));
		return p;
	}

	/**
	 * set infos text
	 *
	 * @param txt
	 */
	public void initInfos(String txt) {
		//LOG.trace(TT + "setInfos(txt=" + txt + ")");
		taInfos.setText(Html.intoHtml(txt));
		taInfos.setCaretPosition(taInfos.getDocument().getLength());
	}

	public void addInfos(String text) {
		initInfos(getInfos() + text);
		taInfos.revalidate();
	}

	public String getInfos() {
		return Html.getBody(taInfos.getText());
	}

	public List<AlbumItem> getItems() {
		return items;
	}

	@Override
	public void doCopyBegin() {
		//LOG.trace(TT + "doExec()");
		dirDest = new File(tfFolder.getText());
		if (cbFormat.getSelectedIndex() == FORMAT_EPUB) {
			dirDest = new File(dirDest, File.separator + "EPUB" + File.separator + "OEBPS");
		}
		dirDest.mkdirs();
		items = new ArrayList<>();
		for (int i = 0; i < table.getRowCount(); i++) {
			File src = (File) table.getValueAt(i, 1);
			String text = (String) table.getValueAt(i, 2);
			items.add(new AlbumItem(i, text, src));
		}
		Dimension dim = null;
		if (cbCompress.getSelectedIndex() == 1) {
			dim = new Dimension(1280, 700);
		}
		if (cbCompress.getSelectedIndex() == 2) {
			dim = new Dimension(1920, 1080);
		}
		boolean istext = false, isremove = false;
		copyDlg = new CopyFileDlg(this, items, istext, dirDest, -1, isremove, dim);
		setCursor(new Cursor(Cursor.WAIT_CURSOR));
		copyDlg.setCompress(cbCompress.getSelectedIndex());
		copyDlg.start();
	}

	@Override
	public void doCopyEnd() {
		//LOG.trace(TT + "doExecSuite() format=" + cbFormat.getSelectedIndex());
		setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		if (!copyDlg.isOK()) {
			return;
		}
		initInfos(getInfos() + copyDlg.getReport());
		Integer format = cbFormat.getSelectedIndex();
		switch (format) {
			case FORMAT_SIMPLE://simply add an album XML file
				makeSimple();
				break;
			case FORMAT_HTML://todo HTML format
				makeHTML();
				break;
			case FORMAT_EPUB://todo EPUB format
				makeEPUB();
				break;
			case FORMAT_MP4://MP4 format with FFmpeg
				try {
					String fx = FileUtil.removeExtension(mainFrame.getAlbumPanel().albumNameGet());
					File mp4 = new File(dirDest, fx + ".mp4");
					makeFFmpeg(dirDest, mp4.getAbsolutePath());
					//todo if ok remove image files
				} catch (IOException ex) {
					LOG.err(TT + "getName() makeFFmpeg error", ex);
				}
				break;
		}
	}

	private void makeEPUB() {
		//LOG.trace(TT + "makeEPUB()");
		addInfos("<br>" + I18N.getMsg("export.format.epub_make"));
		dirDest = new File(tfFolder.getText());
		String fx = FileUtil.removeExtension(mainFrame.getAlbumPanel().albumNameGet());
		File outfile = new File(dirDest, fx + ".epub");
		ExportEPUB.create(this, dirDest);
		addInfos(" " + I18N.getMsg("task.ok") + "</p>");
	}

	public void makeFFmpeg(File dir, String video) throws IOException {
		LOG.trace(TT + "makeFFmpeg(dir=" + dir.getAbsolutePath() + ", outputVideo=" + video + ")");
		String command = String.format(
				"ffmpeg "
				+ "-framerate 1 "
				+ "-pattern_type glob "
				+ "-i '%s/*.jpg' "
				+ "-c:v libx264 "
				+ "-r 30 "
				+ "-pix_fmt yuv420p %s -y",
				dir.getAbsolutePath(), video);
		addInfos("<p>" + I18N.getColonMsg("export.format.mpeg_make") + "<br>" + command + " ...<br>");
		ProcessBuilder processBuilder = new ProcessBuilder("bash", "-c", command);
		Process process = processBuilder.start();
		try {
			process.waitFor();
			addInfos(I18N.getMsg("task.ok") + "</p>");
		} catch (InterruptedException e) {
			LOG.err(TT + "makeFFmpeg(...) call error\n", e);
			addInfos(I18N.getMsg("task.error", e.getLocalizedMessage()) + "</p>");
		}
	}

	private void makeHTML() {
		LOG.trace(TT + "makeHTML()");
		addInfos("<br>" + I18N.getMsg("export.format.html_make"));
		ExportHTML html = new ExportHTML(this, dirDest);
		html.begin(items);
		addInfos(I18N.getMsg("task.ok") + "</p>");
	}

	/**
	 * add an album XML file
	 */
	private void makeSimple() {
		LOG.trace(TT + "makeSimple()");
		addInfos("<br>" + I18N.getMsg("export.format.simple_make"));
		String fx = FileUtil.removeExtension(mainFrame.getAlbumPanel().albumNameGet());
		File outfile = new File(dirDest, fx + ".xml");
		StringBuilder b = new StringBuilder(XML.getHeader())
				.append("<album>\n")
				.append("   <list>\n");
		for (AlbumItem item : items) {
			b.append(itemToXml(item));
		}
		b.append("   </list>\n").append("</album>");
		FileUtil.fileWriteString(outfile, b.toString());
		addInfos(" " + I18N.getMsg("task.ok") + "</p>");
	}

	private String itemToXml(AlbumItem item) {
		String file = item.file.getName();
		return "      <item "
				+ "id=\"" + String.format("%03d", item.id + 1) + "\" "
				+ "file=\"" + file + "\" "
				+ "comment=\"" + item.text + "\" "
				+ " />\n";
	}

}
