/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app.export;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;

/**
 *
 * @author favdb
 */
public class ExportImage {

	private static final String TT = "ExportImage.";

	public static File writeTo(File src, String text, File dirDest, String outName, Dimension dim) throws Exception {
		/*LOG.trace(TT + "writeTo(src=" + src.getAbsolutePath()
				+ ", text='" + text
				+ "', dirDest=" + dirDest.getAbsolutePath()
				+ ", outName=" + outName
				+ ", dim=" + dim.toString()
				+ ")");*/
		BufferedImage originalImage = ImageIO.read(src);
		Dimension newDim = getNewDim(originalImage, dim);
		Image scaledImage = originalImage.getScaledInstance(newDim.width, newDim.height, Image.SCALE_SMOOTH);
		BufferedImage resizedImage = new BufferedImage(newDim.width, newDim.height, BufferedImage.TYPE_INT_RGB);
		Graphics2D g2d = resizedImage.createGraphics();
		g2d.drawImage(scaledImage, 0, 0, null);
		insertText(text, g2d, newDim);
		g2d.dispose();
		File outputFile = new File(dirDest, outName);
		ImageIO.write(resizedImage, "jpg", outputFile);
		return outputFile;
	}

	private static Dimension getNewDim(BufferedImage image, Dimension dim) {
		double aspectRatio = (double) image.getWidth() / image.getHeight();
		int width = dim.width, height = dim.height;
		if (image.getWidth() > image.getHeight()) {
			height = (int) (dim.width / aspectRatio);
			if (height > dim.height) {
				height = dim.height;
				width = (int) (dim.height * aspectRatio);
			}
		} else {
			width = (int) (dim.height * aspectRatio);
			if (width > dim.width) {
				width = dim.width;
				height = (int) (dim.width / aspectRatio);
			}
		}
		return new Dimension(width, height);
	}

	private static void insertText(String text, Graphics2D g2d, Dimension dim) {
		if (text != null && !text.isEmpty()) {
			g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
			g2d.setFont(new Font("Arial", Font.PLAIN, 20));
			FontMetrics fontMetrics = g2d.getFontMetrics();
			int textW = fontMetrics.stringWidth(text), textH = fontMetrics.getHeight();
			int padding = 10, rectHeight = textH + padding * 2;
			g2d.setColor(Color.BLACK);
			g2d.fillRect(0, dim.height - rectHeight, dim.width, rectHeight);
			g2d.setColor(Color.WHITE);
			int x = (dim.width - textW) / 2,
					y = dim.height - padding - fontMetrics.getDescent();
			g2d.drawString(text, x, y);
		}
	}

	public static File writeTo(File file, String text, File outfile, Dimension dim) throws Exception {
		return writeTo(file, text, outfile.getParentFile(), outfile.getName(), dim);
	}

	public static String changeCompression(File infile, File outfile, float compress) {
		try {
			BufferedImage inputImage = ImageIO.read(infile);
			Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpg");
			ImageWriter writer = writers.next();
			try (ImageOutputStream outputStream = ImageIO.createImageOutputStream(outfile)) {
				writer.setOutput(outputStream);
				ImageWriteParam params = writer.getDefaultWriteParam();
				params.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
				if (compress > 0) {
					params.setCompressionQuality(compress);
				}
				writer.write(null, new IIOImage(inputImage, null, null), params);
			}
			writer.dispose();
			return "";
		} catch (IOException ex) {
			return ex.getLocalizedMessage();
		}
	}

}
