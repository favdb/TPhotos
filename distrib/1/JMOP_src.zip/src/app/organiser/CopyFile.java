/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app.organiser;

import app.App;
import i18n.I18N;
import java.io.File;
import java.util.List;
import tools.Html;
import tools.exif.ExifData;
import tools.file.FileUtil;

/**
 *
 * @author favdb
 */
public class CopyFile implements Runnable {

	private final Organiser parent;
	private final List<File> files;
	private int index;
	//private final StringBuilder infos;
	private final int mode;
	private final boolean autoremove;
	private boolean running = true;

	public CopyFile(Organiser parent, List<File> files, File dir, int mode, boolean autoremove) {
		this.parent = parent;
		this.files = files;
		this.mode = mode;
		this.autoremove = autoremove;
		this.index = 0;
		//infos = new StringBuilder(parent.taInfosGet());
	}

	private void addReport(String msg) {
		((Organiser) parent).taInfosAdd(msg);
	}

	@Override
	public void run() {
		//LOG.trace(TT + ".run() index=" + index);
		if (index >= files.size()) {
			done();
			return;
		}
		File infile = files.get(index);
		int infileMD5 = FileUtil.getMD5(infile);
		String date = ExifData.getDate(infile);
		String nl = "";
		if (date != null) {
			String newname = date;
			String outdir = App.preferences.getPhotosDir() + File.separator;
			String subdir = date.substring(0, 4) + File.separator;
			if (mode > 0) {//add month
				subdir += date.substring(4, 6) + File.separator;
			}
			if (mode == 2) {//add days
				subdir += date.substring(6, 8) + File.separator;
			}
			if (mode == 4) {//no subdir
				subdir = "";
			}
			String outname = outdir + subdir + File.separator + newname;
			File outfile = new File(outname + ".jpg");
			String cpl = "";
			int nb = 2;
			if (outfile.exists()) {
				if (infileMD5 == FileUtil.getMD5(outfile)) {
					nb = 100;
				} else {
					for (; nb < 100; nb++) {
						cpl = String.format("_%02d", nb);
						outname = outdir + subdir + newname + cpl + ".jpg";
						File fx = new File(outname);
						if (!fx.exists()) {
							break;
						}
						if (infileMD5 == FileUtil.getMD5(fx)) {
							nb = 100;
							break;
						}
					}
				}
				outfile = new File(outdir + subdir + newname + cpl + ".jpg");
			}
			if (nb < 100) {
				nl = Html.intoGreen(I18N.getMsg("photo.copy_ok", new String[]{infile.getName(), subdir + outfile.getName()}));
				FileUtil.fileCopy(infile, outfile);
				if (autoremove) {
					infile.delete();
				}
			} else {
				nl = Html.intoRed(I18N.getMsg("photo.exists", new String[]{infile.getName(), subdir, newname + ".jpg"}));
			}
			addReport(nl + "<br>");
		}
		if (++index < files.size()) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException ex) {
			}
			run();
		} else {
			done();
		}
		//parent.taInfosSet(infos.toString());
	}

	private void done() {
		addReport(I18N.getMsg("organiser.end", new String[]{
			index + "",
			(index > 1 ? I18N.getMsg("files") : I18N.getMsg("file"))}));
		running = false;
		((Organiser) parent).doCopyEnd();
	}

	public boolean isRunning() {
		return running;
	}

}
