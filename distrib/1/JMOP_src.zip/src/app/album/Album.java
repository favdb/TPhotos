/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app.album;

import api.mig.swing.MigLayout;
import app.App;
import i18n.I18N;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.io.File;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import resources.icons.ICONS;
import resources.icons.IconUtil;
import tools.LOG;
import tools.MIG;
import static tools.Ui.initIconButton;
import tools.xml.Xml;

/**
 *
 * @author favdb
 */
public class Album extends JFrame {

	private static final String TT = "Album.";
	private static final int IMG_SIZE = 200;

	// tree and table
	private AlbumTree albumTree;
	private AlbumTable table;
	// other components
	private JPanel pTable, pImage, pTree;
	private JTextField lbImage;
	private JLabel image;
	private JButton btAdd;
	private String albumName = "Album";
	private AlbumParam albumParam;
	private Xml xml;

	public Album() {
		super();
		initialize();
	}

	public void albumNameSet(String value) {
		this.albumName = value;
	}

	public String albumNameGet() {
		return table.getXml().getFile().getName();
	}

	private void initialize() {
		//LOG.trace(TT + "initialize()");
		xml = new Xml(App.preferences.getPhotosDir() + File.separator + "Album.xml");
		albumParam = new AlbumParam(xml);
		setLayout(new MigLayout(MIG.FILL, "[20%][80%]"));
		JPanel left = new JPanel(new MigLayout(MIG.get(MIG.FILL, MIG.WRAP), "[grow]"));
		left.setMaximumSize(Toolkit.getDefaultToolkit().getScreenSize());
		left.add(initTree(), MIG.get(MIG.GROW));
		left.add(initImage(), MIG.get(MIG.GROW));
		add(left, MIG.GROWY);
		add(initTable(), MIG.GROW);
		setPreferredSize(Toolkit.getDefaultToolkit().getScreenSize());
		setMaximumSize(Toolkit.getDefaultToolkit().getScreenSize());
	}

	private JPanel initTree() {
		//LOG.trace(TT + "initTree()");
		pTree = new JPanel(new MigLayout(MIG.get(MIG.FILL, MIG.INS0)));
		albumTree = new AlbumTree(this);
		albumTree.addTreeSelectionListener(e -> treeChanged());
		JScrollPane scroll = new JScrollPane(albumTree);
		//scroll.setMinimumSize(new Dimension(200, 200));
		pTree.add(scroll, MIG.GROW);
		return pTree;
	}

	private JPanel initImage() {
		//LOG.trace(TT + "initImage()");
		pImage = new JPanel(new MigLayout(MIG.get(MIG.FILL, MIG.INS0), "[grow][]"));
		lbImage = new JTextField(" ");
		lbImage.setHorizontalAlignment(JTextField.CENTER);
		lbImage.setColumns(32);
		lbImage.setBorder(null);
		lbImage.setEditable(false);
		pImage.add(lbImage, MIG.get(MIG.GROWX, MIG.SPAN, MIG.CENTER));
		pImage.add(image = new JLabel(I18N.getMsg("photo.preview")), MIG.GROW);
		image.setMinimumSize(new Dimension(IMG_SIZE + 5, IMG_SIZE + 5));
		image.setMaximumSize(Toolkit.getDefaultToolkit().getScreenSize());
		image.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		//image.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
		image.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
		pImage.add(btAdd
				= initIconButton("btAdd", ICONS.K.NAV_NEXT, (ActionEvent evt) -> btAddAction()));
		btAdd.setEnabled(false);
		return pImage;
	}

	private void btAddAction() {
		//LOG.trace(TT + "btAdd");
		if (!AlbumParamDlg.showing(this)) {
			return;
		}
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) albumTree.getLastSelectedPathComponent();
		if (node == null) {
			return;
		}
		TreePath[] paths = albumTree.getSelectionPaths();
		if (node.isLeaf() && paths.length == 1) {
			File imgFile = new File(albumTree.getPath(node));
			lbImage.setText(imgFile.getName());
			// add unique file
			if (App.jpegIs(imgFile)) {
				Object obj[] = {
					table.getRowCount() + 1,
					imgFile,
					albumParam.getComment(imgFile)
				};
				table.addRow(obj);
			}
		} else {
			for (TreePath path : albumTree.getSelectionPaths()) {
				String nf = path.getLastPathComponent().toString();
				File fl = new File(nf);
				if (fl.isDirectory()) {
					addDir(fl);
				} else if (App.jpegIs(fl)) {
					addFile(fl);
				}
			}
		}
	}

	private void addDir(File dir) {
		//LOG.trace(TT + "addDir(dir=" + dir.getName() + ")");
		File[] files = dir.listFiles();
		for (File f : files) {
			if (f.isDirectory()) {
				addDir(f);
			}
			if (App.jpegIs(f)) {
				addFile(f);
			}
		}
	}

	private void addFile(File file) {
		//LOG.trace(TT + "addFile(file=" + file.getName() + ")");
		Object obj[] = {table.getRowCount() + 1, file, albumParam.getComment(file)};
		table.addRow(obj);
	}

	private JPanel initTable() {
		//LOG.trace(TT + "initTable()");
		pTable = new JPanel(new MigLayout(MIG.get(MIG.FILL, MIG.INS0)));
		table = new AlbumTable(this);
		table.setMaximumSize(Toolkit.getDefaultToolkit().getScreenSize());
		table.getSelectionModel().addListSelectionListener((ListSelectionEvent event) -> {
			if (table.getRowCount() == 0) {
				resetImage();
				return;
			}
			int[] rows = table.getSelectedRows();
			if (rows == null || rows.length != 1) {
				resetImage();
				return;
			}
			File imgFile = (File) table.getValueAt(rows[0], 1);
			resetImage();
			image.setIcon(IconUtil.getJpegIconFromFile(imgFile, IMG_SIZE));
			btAdd.setEnabled(false);
		});
		JScrollPane scroll = new JScrollPane(table);
		scroll.setMaximumSize(Toolkit.getDefaultToolkit().getScreenSize());
		pTable.add(scroll, MIG.GROW);
		return pTable;
	}

	public AlbumTable getTable() {
		return table;
	}

	private void treeChanged() {
		LOG.trace(TT + "treeChanged()");
		/*if (table.getRowCount() < 1) {
			return;
		}*/
		btAdd.setEnabled(true);
		TreePath[] paths = albumTree.getSelectionPaths();
		lbImage.setText("");
		if (paths != null && paths.length > 1) {
			image.setText(I18N.getMsg("photo.selected", paths.length));
			image.setIcon(null);
			return;
		}
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) albumTree.getLastSelectedPathComponent();
		if (node == null) {
			return;
		}
		File imgFile = new File(albumTree.getPath(node));
		lbImage.setText(imgFile.getName());
		if (node.isLeaf()) {
			if (App.jpegIs(imgFile)) {
				image.setText("");
				image.setIcon(IconUtil.getJpegIconFromFile(imgFile, IMG_SIZE));
				btAdd.setEnabled(true);
			}
		} else {
			image.setIcon(null);
			image.setText(String.format("%d photos", App.jpegCount(imgFile)));
		}
	}

	public void loadTable() {
		table.load(xml);
		loadParam();
	}

	public void loadTable(File file) {
		xml = new Xml(file.getAbsolutePath());
		loadTable();
	}

	public void savePref() {
		albumParam.updateXml(xml);
	}

	public Xml getXml() {
		return table.getXml();
	}

	public AlbumParam getAlbumParam() {
		return albumParam;
	}

	public void loadParam() {
		albumParam = new AlbumParam(table.getXml());
	}

	public void albumParamCreate() {
		if (table != null && table.xml.isOpened()) {
			loadParam();
		}
	}

	public void setAlbumFile(File file) {
		if (table.isModified()) {
			table.save();
		}
		xml = new Xml(file);
		table.load(xml);
		loadParam();
		albumTree.reload();
	}

	public void setPhotosDir(File file) {
		setAlbumFile(new File(App.preferences.getPhotosDir() + File.separator + "Album.xml"));
	}

	private void resetImage() {
		lbImage.setText("");
		image.setText("");
		image.setIcon(null);
	}

}
