/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package app.album;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import tools.LOG;
import tools.file.FileUtil;
import tools.xml.Xml;
import tools.xml.XmlUtil;

/**
 *
 * @author favdb
 */
public class AlbumParam {

	private String name = "Album", comment = "{JJ/MM/AAAA}";
	private Integer mode = 0, tempo = 0;

	public AlbumParam() {

	}

	public AlbumParam(Xml xml) {
		Node n = xml.getNode("pref");
		if (n != null) {
			mode = XmlUtil.getInteger(n, "mode");
			tempo = XmlUtil.getInteger(n, "tempo");
			comment = XmlUtil.getString(n, "comment");
		} else {
			xml.childCreate(xml.getRoot(), "pref");
		}
	}

	public void setMode(int value) {
		this.mode = value;
	}

	public Integer getMode() {
		if (mode < 0) {
			return 0;
		}
		return mode;
	}

	public void setTempo(int value) {
		this.tempo = value;
	}

	public Integer getTempo() {
		if (tempo < 0) {
			return 0;
		}
		return tempo;
	}

	public void setComment(String value) {
		this.comment = value;
	}

	public String getComment() {
		return comment;
	}

	public String getComment(File file) {
		String dt = FileUtil.removeExtension(file.getName());
		String str = comment;
		if (comment.contains("{") && comment.contains("}")) {
			SimpleDateFormat fm1 = new SimpleDateFormat("yyyyMMdd_HHmmss");
			SimpleDateFormat fm2 = new SimpleDateFormat("dd/MM/yyyy");
			String sub = "{JJ/MM/AAAA}";
			if (comment.contains("{JJ/MM/AAAA}")) {
				fm2 = new SimpleDateFormat("dd/MM/yyyy");
			} else if (comment.contains("{MM/AAAA}")) {
				fm2 = new SimpleDateFormat("MM/yyyy");
				sub = "{MM/AAAA}";
			} else if (comment.contains("{AAAA}")) {
				fm2 = new SimpleDateFormat("yyyy");
				sub = "{AAAA}";
			} else if (comment.contains("{MMM AAAA}")) {
				fm2 = new SimpleDateFormat("MMM yyyy");
				sub = "{MMM AAAA}";
			}
			try {
				Date date = fm1.parse(dt);
				str = comment.replace(sub, fm2.format(date));
			} catch (ParseException ex) {
				LOG.err("getComment error", ex);
			}
		}
		return str;
	}

	public void updateXml(Xml xml) {
		Element n = (Element) xml.getNode("pref");
		if (n == null) {
			n = xml.getDocument().createElement("pref");
			xml.getRoot().appendChild(n);
		}
		mode = Math.max(mode, 0);
		tempo = Math.max(tempo, 0);
		n.setAttribute("mode", mode.toString());
		n.setAttribute("tempo", tempo.toString());
		n.setAttribute("comment", comment);
	}

	public String toXml() {
		StringBuilder b = new StringBuilder("   <pref ");
		b.append("comment=\"").append(comment).append("\" ");
		b.append("mode=\"").append(mode.toString()).append("\" ");
		b.append("tempo=\"").append(tempo.toString()).append("\" ");
		b.append("/>\n");
		return b.toString();
	}

}
