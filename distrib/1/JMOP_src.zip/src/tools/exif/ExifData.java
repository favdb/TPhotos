/*
 * Copyright (C) 2024 favdb
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package tools.exif;

import com.drew.imaging.ImageMetadataReader;
import com.drew.imaging.ImageProcessingException;
import com.drew.metadata.Directory;
import com.drew.metadata.Metadata;
import com.drew.metadata.exif.ExifSubIFDDirectory;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.FileTime;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author favdb
 */
public class ExifData {

	private static final String filename = "/home/favdb/transfert/camera/IMG_20210115_145603.jpg";

	public static void main(String[] args) {
		String str = getDate(new File(filename));
		if (str != null) {
			System.out.println("Date de prise de vue : " + str);
		} else {
			System.err.println("Date de prise de vue non trouvée");
		}
	}

	public static String getDate(File file) {
		try {
			Metadata metadata = ImageMetadataReader.readMetadata(file);
			// Rechercher la date de prise de vue dans les métadonnées EXIF
			for (Directory directory : metadata.getDirectories()) {
				if (directory.containsTag(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL)) {
					String s = directory.getString(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL);
					// reformattage de la date
					if (s != null && !s.isEmpty()) {
						return s.replace(":", "").replace(" ", "_");
					}
				}
			}
			FileTime ct = (FileTime) Files.getAttribute(file.toPath(), "creationTime");
			if (ct != null) {
				LocalDateTime lt = ct.toInstant()
					.atZone(ZoneId.systemDefault()).toLocalDateTime();
				return lt.format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
			}
		} catch (ImageProcessingException | IOException e) {
			e.printStackTrace(System.err);
		}
		return null;
	}

}
